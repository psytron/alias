
from .alias import Alias # expose Alias class directly at module level

def info( *args ,**kwargs):
    print(' Alias XL ')