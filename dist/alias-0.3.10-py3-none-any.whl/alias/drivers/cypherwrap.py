


import blockcypher


print( blockcypher.get_total_balance('xxxe4dc60d18793421f81be0c05f0546052') )